<?php
/*
--------
Channel=>@soros_robot
Channel=>@lite_team
--------
*/
define('API_KEY','449314973:AAHk2ue0EkFXwdecTVc1swu03aevPNUioCA');
//----######------
function makereq($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($datas));
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//##############=--API_REQ
function apiRequest($method, $parameters) {
  if (!is_string($method)) {
    error_log("Method name must be a string\n");
    return false;
  }
  if (!$parameters) {
    $parameters = array();
  } else if (!is_array($parameters)) {
    error_log("Parameters must be an array\n");
    return false;
  }
  foreach ($parameters as $key => &$val) {
    // encoding to JSON array parameters, for example reply_markup
    if (!is_numeric($val) && !is_string($val)) {
      $val = json_encode($val);
    }
  }
  $url = "https://api.telegram.org/bot".API_KEY."/".$method.'?'.http_build_query($parameters);
  $handle = curl_init($url);
  curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 5);
  curl_setopt($handle, CURLOPT_TIMEOUT, 60);
  return exec_curl_request($handle);
}
//----######------
//---------
$update = json_decode(file_get_contents('php://input'));
var_dump($update);
//=========
$chat_id = $update->message->chat->id;
$message_id = $update->message->message_id;
$from_id = $update->message->from->id;
$name = $update->message->from->first_name;
$username = $update->message->from->username;
$textmessage = isset($update->message->text)?$update->message->text:'';
$txtmsg = $update->message->text;
$reply = $update->message->reply_to_message->forward_from->id;
$stickerid = $update->message->reply_to_message->sticker->file_id;
$admin = 306553098;
$channel = '@cptnhack';
$logch = '@cptnhack';
$step = file_get_contents("data/".$from_id."/step.txt");
$ban = file_get_contents('data/banlist.txt');
$vip = file_get_contents('data/vip.txt');
//-------
function SendMessage($ChatId, $TextMsg)
{
 makereq('sendMessage',[
'chat_id'=>$ChatId,
'text'=>$TextMsg,
'parse_mode'=>"MarkDown"
]);
}
function SendSticker($ChatId, $sticker_ID)
{
 makereq('sendSticker',[
'chat_id'=>$ChatId,
'sticker'=>$sticker_ID
]);
}
function Forward($KojaShe,$AzKoja,$KodomMSG)
{
makereq('ForwardMessage',[
'chat_id'=>$KojaShe,
'from_chat_id'=>$AzKoja,
'message_id'=>$KodomMSG
]);
}
function save($filename,$TXTdata)
	{
	$myfile = fopen($filename, "w") or die("Unable to open file!");
	fwrite($myfile, "$TXTdata");
	fclose($myfile);
	}
if (strpos($ban , "$from_id") !== false  ) {
SendMessage($chat_id,"😊 شما از ربات مسدود شده اید !
📢 لطفا دیگه پیامی ارسال نکنید . . .");
	}

		elseif ($from_id != $chat_id) {
		
	SendMessage($chat_id,"😶😐");
makereq('leaveChat',[
	'chat_id'=>$chat_id
	]);
	}
	
elseif(isset($update->callback_query)){
    $callbackMessage = '';
    var_dump(makereq('answerCallbackQuery',[
        'callback_query_id'=>$update->callback_query->id,
        'text'=>$callbackMessage
    ]));
    $chat_id = $update->callback_query->message->chat->id;
    
    $message_id = $update->callback_query->message->message_id;
    $data = $update->callback_query->data;
    if (strpos($data, "del") !== false ) {
    $botun = str_replace("del ","",$data);
    unlink("bots/".$botun."/index.php");
    save("data/$chat_id/bots.txt","");
    save("data/$chat_id/tedad.txt","0");
    var_dump(
        makereq('editMessageText',[
            'chat_id'=>$chat_id,
            'message_id'=>$message_id,
            'text'=>"ربات شما با موفقیت حذف شد !",
            'reply_markup'=>json_encode([
                'inline_keyboard'=>[
                    [
                        ['text'=>"به کانال ما بپیوندید",'url'=>"https://telegram.me/soros_robot"]
                    ]
                ]
            ])
        ])
    );
	SendMessage($logch,"`🔻رباتی توسط ادمین آن در سرور ربات حذف گردید . . .`

📢 اطلاعات آن ربات :

🔸*Bot Username :* [$botun](http://t.me/$botun)");
 }
 else {
    var_dump(
        makereq('editMessageText',[
            'chat_id'=>$chat_id,
            'message_id'=>$message_id,
            'text'=>"خطا",
            'reply_markup'=>json_encode([
                'inline_keyboard'=>[
                    [
                        ['text'=>"به کانال ما بپیوندید",'url'=>"https://telegram.me/soros_robot"]
                    ]
                ]
            ])
        ])
    );
 }
}

elseif ($textmessage == '🔙 خروج از پنل مدیریت') {
save("data/$from_id/step.txt","none");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🔃 از پنل مدیریت خارج شدید",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
                   ['text'=>"🔄 ساخت ربات"],['text'=>"🚀 ربات های من"]
                ],
                [
				   ['text'=>"☢ حذف ربات"],['text'=>"ℹ️ راهنما"]
				],
                [
                   ['text'=>"✅ ارسال نظر"],['text'=>"⚠️ گزارش تخلف"]
                ],
           [
                ['text'=>"🗣 پشتیبانی"]
            ]
                
             ],
             'resize_keyboard'=>true
         ])
      ]));
}
elseif ($textmessage == '🔙 برگشت به منوی اصلی') {
save("data/$from_id/step.txt","none");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🔃 به منوی اصلی خوش آمدید",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
                   ['text'=>"🔄 ساخت ربات"],['text'=>"🚀 ربات های من"]
                ],
                [
				   ['text'=>"☢ حذف ربات"],['text'=>"ℹ️ راهنما"]
				],
                [
                   ['text'=>"✅ ارسال نظر"],['text'=>"⚠️ گزارش تخلف"]
                ],
           [
                ['text'=>"🗣 پشتیبانی"]
            ]
                
             ],
             'resize_keyboard'=>true
         ])
      ]));
}
elseif ($textmessage == '🔙 برگشت به بخش ویژه') {
if (strpos($vip , "$from_id") !== false  ) {
	save("data/$from_id/step.txt","none");
			var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🔃 به منوی بخش ویژه خوش آمدید",
			'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
                     ['text'=>"💬 ساخت ربات پیام رسان ویژه"],['text'=>""]
                ],
                [
                   ['text'=>"❌ ساخت ربات Xo ویژه"],['text'=>"👤 ساخت ربات یوزر اینفو ویژه"]
                ],
                [
				   ['text'=>"📧 ساخت ربات فیک میل ویژه"],['text'=>"🔗 ساخت ربات کوتاه کننده لینک ویژه"]
				],
                [
                   ['text'=>'🔙 برگشت به منوی اصلی']
                ]
            	],
            	'resize_keyboard'=>true
       		])
    		]));
        }
		else {
			SendMessage($chat_id,"⚜️ متاسفانه حساب شما عادی است.");
		}
	}
	elseif ($textmessage == '🔸ورود به بخش ویژه🔸') {
if (strpos($vip , "$from_id") !== false  ) {
	save("data/$from_id/step.txt","none");
			var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🔸به بخش ویژه خوش آمدید. برای ساخت ربات یکی از دکمه های زیر را انتخاب کنید.",
			'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
				[
                     ['text'=>"💬 ساخت ربات پیام رسان ویژه"],['text'=>""]
                ],
                [
                   ['text'=>"❌ ساخت ربات Xo ویژه"],['text'=>"👤 ساخت ربات یوزر اینفو ویژه"]
                ],
                [
				   ['text'=>"📧 ساخت ربات فیک میل ویژه"],['text'=>"🔗 ساخت ربات کوتاه کننده لینک ویژه"]
				],
                [
                   ['text'=>'🔙 برگشت به منوی اصلی']
                ]
            	],
            	'resize_keyboard'=>true
       		])
    		]));
        }
		else {
			SendMessage($chat_id,"⚜️ متاسفانه حساب شما عادی است.
➖➖➖➖➖➖➖➖➖➖➖➖➖
🔸مزایا اکانت ویژه :

1⃣ ساخت ربات Php بدون تبلیغات
2⃣ پاسخگویی سریعتر در پشتیبانی
3⃣ در اولویت بودن آپدیت ها برای اکانت های ویژه
4⃣ درخواست اضافه کردن سورس توسط اکانت های ویژه پیگیری میشود 

💰 قیمت ویژه شدن اکانت شما در ربات فقط و فقط 2000 تومان میباشد.

📡 پرداخت بصورت درگاه اینترنتی :
http://yeo.ir/inv
↩️ پس از پرداخت به ایدی های زیر پیام دهید :
@SuCrPvBot");
		}
	}
elseif ($textmessage == '🔙 برگشت به بخش عادی') {
save("data/$from_id/step.txt","none");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🔃 به منوی بخش عادی خوش آمدید",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
				   ['text'=>"💬 ساخت ربات پیام رسان"],['text'=>""]
                ],
                [
                   ['text'=>"❌ ساخت ربات Xo"],['text'=>"👤 ساخت ربات یوزر اینفو"]
                ],
                [
				   ['text'=>"📧 ساخت ربات فیک میل"],['text'=>"🔗 ساخت ربات کوتاه کننده لینک"]
				],
                [
                   ['text'=>""],['text'=>""]
                ],
           [
                ['text'=>"🔙 برگشت به منوی اصلی"]
            ]
                
             ],
             'resize_keyboard'=>true
         ])
      ]));
}
elseif ($textmessage == '🔹ورود به بخش عادی🔹') {
save("data/$from_id/step.txt","none");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🔹به بخش عادی خوش آمدید. برای ساخت ربات یکی از دکمه های زیر را انتخاب کنید.",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
				   ['text'=>"💬 ساخت ربات پیام رسان"],['text'=>""]
                ],
                [
                   ['text'=>"❌ ساخت ربات Xo"],['text'=>"👤 ساخت ربات یوزر اینفو"]
                ],
                [
				   ['text'=>"📧 ساخت ربات فیک میل"],['text'=>"🔗 ساخت ربات کوتاه کننده لینک"]
				],
                [
                   ['text'=>""],['text'=>""]
                ],
           [
                ['text'=>"🔙 برگشت به منوی اصلی"]
            ]
                
             ],
             'resize_keyboard'=>true
         ])
      ]));
}
elseif ($textmessage == '🔄 ساخت ربات') {
save("data/$from_id/step.txt","none");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🔰 یکی از دکمه ها را انتخاب کنید.",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
				   ['text'=>"🔸ورود به بخش ویژه🔸"],['text'=>""]
                ],
                [
                   ['text'=>"🔹ورود به بخش عادی🔹"],['text'=>""]
                ],
                [
				   ['text'=>""],['text'=>""]
				],
                [
                   ['text'=>""],['text'=>""]
                ],
           [
                ['text'=>"🔙 برگشت به منوی اصلی"]
            ]
                
             ],
             'resize_keyboard'=>true
         ])
      ]));
}
elseif ($step == 'delete') {
$botun = $txtmsg ;
if (file_exists("bots/".$botun."/index.php")) {

$src = file_get_contents("bots/".$botun."/index.php");

if (strpos($src , $from_id) !== false ) {
save("data/$from_id/step.txt","none");
unlink("bots/".$botun."/index.php");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🚀 ربات شما با موفقیت پاک شده است 
یک ربات جدید بسازید 😄",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"/start"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
}
else {
SendMessage($chat_id,"خطا!
شما نمی توانید این ربات را پاک کنید !");
}
}
else {
SendMessage($chat_id,"یافت نشد.");
}
}
elseif ($step == 'xo') {
$token = $textmessage ;

			$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
			//==================
			function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}

	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
		if($ok != 1) {
			//Token Not True
			SendMessage($chat_id,"توکن نامعتبر!");
		}
		else
		{
		SendMessage($chat_id,"در حال ساخت ربات ...");
		file_put_contents("bots/$un/vip.txt","free");
		file_put_contents("bots/$un/ad_vip.txt","BOTSAZ_TEAM");
        file_put_contents("bots/$un/step.txt","none");
		file_put_contents("bots/$un/users.txt","");
		file_put_contents("bots/$un/token.txt","$text");
        file_put_contents("bots/$un/start.txt","سلام 😊👋
به ربات دوز خوش اومدي ! ❤️‌ , اگه ميخواي تو گروهات يا پي وي هات با دوستات دوز بازي كنيد و حوصلتون سر رفته روي شروع بازي بزن و بازيو شروع كن😉 وقتي بازي تموم شد  نتايج اعلام ميشه");
		if (file_exists("bots/$un/index.php")) {
		$source = file_get_contents("bot/xo.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"♻️🚀 ربات شما با موفقیت آپدیت شد !",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
		}
		else {
		save("data/$from_id/tedad.txt","1");
		save("data/$from_id/step.txt","none");
		save("data/$from_id/bots.txt","$un");
		
		mkdir("bots/$un");
		mkdir("bots/$un/data");
		mkdir("bots/$un/data/btn");
		mkdir("bots/$un/data/words");
		mkdir("bots/$un/data/profile");
		mkdir("bots/$un/data/setting");
		
		save("bots/$un/data/blocklist.txt","");
		save("bots/$un/data/last_word.txt","");
		save("bots/$un/data/pmsend_txt.txt","📮Message Sent!");
		save("bots/$un/data/start_txt.txt","Hello Wellcome To My Robot 😉👌
Send Me Your Message 🌹");
		save("bots/$un/data/forward_id.txt","");
		save("bots/$un/data/users.txt","$from_id\n");
		mkdir("bots/$un/data/$from_id");
		save("bots/$un/data/$from_id/type.txt","admin");
		save("bots/$un/data/$from_id/step.txt","none");
		
		save("bots/$un/data/btn/btn1_name","");
		save("bots/$un/data/btn/btn2_name","");
		save("bots/$un/data/btn/btn3_name","");
		save("bots/$un/data/btn/btn4_name","");
		
		save("bots/$un/data/btn/btn1_post","");
		save("bots/$un/data/btn/btn2_post","");
		save("bots/$un/data/btn/btn3_post","");
		save("bots/$un/data/btn/btn4_post","");
	
		save("bots/$un/data/setting/sticker.txt","✅");
		save("bots/$un/data/setting/video.txt","✅");
		save("bots/$un/data/setting/voice.txt","✅");
		save("bots/$un/data/setting/file.txt","✅");
		save("bots/$un/data/setting/photo.txt","✅");
		save("bots/$un/data/setting/music.txt","✅");
		save("bots/$un/data/setting/forward.txt","✅");
		save("bots/$un/data/setting/joingp.txt","✅");
		
		file_put_contents("bots/$un/vip.txt","free");
		file_put_contents("bots/$un/ad_vip.txt","BOTSAZ_TEAM");
        file_put_contents("bots/$un/step.txt","none");
		file_put_contents("bots/$un/users.txt","");
		file_put_contents("bots/$un/token.txt","$text");
        file_put_contents("bots/$un/start.txt","سلام 😊👋
به ربات دوز خوش اومدي ! ❤️‌ , اگه ميخواي تو گروهات يا پي وي هات با دوستات دوز بازي كنيد و حوصلتون سر رفته روي شروع بازي بزن و بازيو شروع كن😉 وقتي بازي تموم شد  نتايج اعلام ميشه");
		$source = file_get_contents("bot/xo.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🚀 ربات شما با موفقیت نصب شد !",		
                'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
			SendMessage($logch,"`🎗ربات جدیدی در سرور ربات ثبت گردید . . .`

ℹ️اطلاعات ربات ثبت شده :

🔸*Bot Username :* [$un](http://t.me/$un)
🔹*Bot Admin :* [$name](http://t.me/$username)
🔸*Bot Model :* ❌ ربات Xo");
		}
}
}
elseif ($step == 'uinfo') {
$token = $textmessage ;

			$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
			//==================
			function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}

	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
		if($ok != 1) {
			//Token Not True
			SendMessage($chat_id,"توکن نامعتبر!");
		}
		else
		{
		SendMessage($chat_id,"در حال ساخت ربات ...");
		if (file_exists("bots/$un/index.php")) {
		$source = file_get_contents("bot/uinfo.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"♻️🚀 ربات شما با موفقیت آپدیت شد !",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
		}
		else {
		save("data/$from_id/tedad.txt","1");
		save("data/$from_id/step.txt","none");
		save("data/$from_id/bots.txt","$un");
		
		mkdir("bots/$un");
		mkdir("bots/$un/data");
		mkdir("bots/$un/data/btn");
		mkdir("bots/$un/data/words");
		mkdir("bots/$un/data/profile");
		mkdir("bots/$un/data/setting");
		
		save("bots/$un/data/blocklist.txt","");
		save("bots/$un/data/last_word.txt","");
		save("bots/$un/data/pmsend_txt.txt","📮Message Sent!");
		save("bots/$un/data/start_txt.txt","Hello Wellcome To My Robot 😉👌
Send Me Your Message 🌹");
		save("bots/$un/data/forward_id.txt","");
		save("bots/$un/data/users.txt","$from_id\n");
		mkdir("bots/$un/data/$from_id");
		save("bots/$un/data/$from_id/type.txt","admin");
		save("bots/$un/data/$from_id/step.txt","none");
		
		save("bots/$un/data/btn/btn1_name","");
		save("bots/$un/data/btn/btn2_name","");
		save("bots/$un/data/btn/btn3_name","");
		save("bots/$un/data/btn/btn4_name","");
		
		save("bots/$un/data/btn/btn1_post","");
		save("bots/$un/data/btn/btn2_post","");
		save("bots/$un/data/btn/btn3_post","");
		save("bots/$un/data/btn/btn4_post","");
	
		save("bots/$un/data/setting/sticker.txt","✅");
		save("bots/$un/data/setting/video.txt","✅");
		save("bots/$un/data/setting/voice.txt","✅");
		save("bots/$un/data/setting/file.txt","✅");
		save("bots/$un/data/setting/photo.txt","✅");
		save("bots/$un/data/setting/music.txt","✅");
		save("bots/$un/data/setting/forward.txt","✅");
		save("bots/$un/data/setting/joingp.txt","✅");
		

		$source = file_get_contents("bot/uinfo.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🚀 ربات شما با موفقیت نصب شد !",		
                'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
			SendMessage($logch,"`🎗ربات جدیدی در سرور ربات ثبت گردید . . .`

ℹ️اطلاعات ربات ثبت شده :

🔸*Bot Username :* [$un](http://t.me/$un)
🔹*Bot Admin :* [$name](http://t.me/$username)
🔸*Bot Model :* 👤 ربات یوزر اینفو");
		}
}
}
elseif ($step == 'fm') {
$token = $textmessage ;

			$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
			//==================
			function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}

	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
		if($ok != 1) {
			//Token Not True
			SendMessage($chat_id,"توکن نامعتبر!");
		}
		else
		{
		SendMessage($chat_id,"در حال ساخت ربات ...");
		if (file_exists("bots/$un/index.php")) {
		$source = file_get_contents("bot/fm.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"♻️🚀 ربات شما با موفقیت آپدیت شد !",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
		}
		else {
		save("data/$from_id/tedad.txt","1");
		save("data/$from_id/step.txt","none");
		save("data/$from_id/bots.txt","$un");
		
		mkdir("bots/$un");
		mkdir("bots/$un/data");
		mkdir("bots/$un/data/btn");
		mkdir("bots/$un/data/words");
		mkdir("bots/$un/data/profile");
		mkdir("bots/$un/data/setting");
		
		save("bots/$un/data/blocklist.txt","");
		save("bots/$un/data/last_word.txt","");
		save("bots/$un/data/pmsend_txt.txt","📮Message Sent!");
		save("bots/$un/data/start_txt.txt","Hello Wellcome To My Robot 😉👌
Send Me Your Message 🌹");
		save("bots/$un/data/forward_id.txt","");
		save("bots/$un/data/users.txt","$from_id\n");
		mkdir("bots/$un/data/$from_id");
		save("bots/$un/data/$from_id/type.txt","admin");
		save("bots/$un/data/$from_id/step.txt","none");
		
		save("bots/$un/data/btn/btn1_name","");
		save("bots/$un/data/btn/btn2_name","");
		save("bots/$un/data/btn/btn3_name","");
		save("bots/$un/data/btn/btn4_name","");
		
		save("bots/$un/data/btn/btn1_post","");
		save("bots/$un/data/btn/btn2_post","");
		save("bots/$un/data/btn/btn3_post","");
		save("bots/$un/data/btn/btn4_post","");
	
		save("bots/$un/data/setting/sticker.txt","✅");
		save("bots/$un/data/setting/video.txt","✅");
		save("bots/$un/data/setting/voice.txt","✅");
		save("bots/$un/data/setting/file.txt","✅");
		save("bots/$un/data/setting/photo.txt","✅");
		save("bots/$un/data/setting/music.txt","✅");
		save("bots/$un/data/setting/forward.txt","✅");
		save("bots/$un/data/setting/joingp.txt","✅");
		

		$source = file_get_contents("bot/fm.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🚀 ربات شما با موفقیت نصب شد !",		
                'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
			SendMessage($logch,"`🎗ربات جدیدی در سرور ربات ثبت گردید . . .`

ℹ️اطلاعات ربات ثبت شده :

🔸*Bot Username :* [$un](http://t.me/$un)
🔹*Bot Admin :* [$name](http://t.me/$username)
🔸*Bot Model :* 📧 ربات فیک میل");
		}
}
}
elseif ($step == 'sh') {
$token = $textmessage ;

			$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
			//==================
			function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}

	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
		if($ok != 1) {
			//Token Not True
			SendMessage($chat_id,"توکن نامعتبر!");
		}
		else
		{
		SendMessage($chat_id,"در حال ساخت ربات ...");
		if (file_exists("bots/$un/index.php")) {
		$source = file_get_contents("bot/sh.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"♻️🚀 ربات شما با موفقیت آپدیت شد !",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
		}
		else {
		save("data/$from_id/tedad.txt","1");
		save("data/$from_id/step.txt","none");
		save("data/$from_id/bots.txt","$un");
		
		mkdir("bots/$un");
		mkdir("bots/$un/data");
		mkdir("bots/$un/data/btn");
		mkdir("bots/$un/data/words");
		mkdir("bots/$un/data/profile");
		mkdir("bots/$un/data/setting");
		
		save("bots/$un/data/blocklist.txt","");
		save("bots/$un/data/last_word.txt","");
		save("bots/$un/data/pmsend_txt.txt","📮Message Sent!");
		save("bots/$un/data/start_txt.txt","Hello Wellcome To My Robot 😉👌
Send Me Your Message 🌹");
		save("bots/$un/data/forward_id.txt","");
		save("bots/$un/data/users.txt","$from_id\n");
		mkdir("bots/$un/data/$from_id");
		save("bots/$un/data/$from_id/type.txt","admin");
		save("bots/$un/data/$from_id/step.txt","none");
		
		save("bots/$un/data/btn/btn1_name","");
		save("bots/$un/data/btn/btn2_name","");
		save("bots/$un/data/btn/btn3_name","");
		save("bots/$un/data/btn/btn4_name","");
		
		save("bots/$un/data/btn/btn1_post","");
		save("bots/$un/data/btn/btn2_post","");
		save("bots/$un/data/btn/btn3_post","");
		save("bots/$un/data/btn/btn4_post","");
	
		save("bots/$un/data/setting/sticker.txt","✅");
		save("bots/$un/data/setting/video.txt","✅");
		save("bots/$un/data/setting/voice.txt","✅");
		save("bots/$un/data/setting/file.txt","✅");
		save("bots/$un/data/setting/photo.txt","✅");
		save("bots/$un/data/setting/music.txt","✅");
		save("bots/$un/data/setting/forward.txt","✅");
		save("bots/$un/data/setting/joingp.txt","✅");
		

		$source = file_get_contents("bot/sh.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🚀 ربات شما با موفقیت نصب شد !",		
                'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
			SendMessage($logch,"`🎗ربات جدیدی در سرور ربات ثبت گردید . . .`

ℹ️اطلاعات ربات ثبت شده :

🔸*Bot Username :* [$un](http://t.me/$un)
🔹*Bot Admin :* [$name](http://t.me/$username)
🔸*Bot Model :* 🔗 ربات کوتاه کننده لینک");
		}
}
}
elseif ($step == 'pv') {
$token = $textmessage ;

			$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
			//==================
			function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}

	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
		if($ok != 1) {
			//Token Not True
			SendMessage($chat_id,"توکن نامعتبر!");
		}
		else
		{
		SendMessage($chat_id,"در حال ساخت ربات ...");
		if (file_exists("bots/$un/index.php")) {
		$source = file_get_contents("bot/pv.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"♻️🚀 ربات شما با موفقیت آپدیت شد !",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
		}
		else {
		save("data/$from_id/tedad.txt","1");
		save("data/$from_id/step.txt","none");
		save("data/$from_id/bots.txt","$un");
		
		mkdir("bots/$un");
		mkdir("bots/$un/data");
		mkdir("bots/$un/data/btn");
		mkdir("bots/$un/data/words");
		mkdir("bots/$un/data/profile");
		mkdir("bots/$un/data/setting");
		
		save("bots/$un/data/blocklist.txt","");
		save("bots/$un/data/last_word.txt","");
		save("bots/$un/data/pmsend_txt.txt","📮Message Sent!");
		save("bots/$un/data/start_txt.txt","Hello Wellcome To My Robot 😉👌
Send Me Your Message 🌹");
		save("bots/$un/data/forward_id.txt","");
		save("bots/$un/data/users.txt","$from_id\n");
		mkdir("bots/$un/data/$from_id");
		save("bots/$un/data/$from_id/type.txt","admin");
		save("bots/$un/data/$from_id/step.txt","none");
		
		save("bots/$un/data/btn/btn1_name","");
		save("bots/$un/data/btn/btn2_name","");
		save("bots/$un/data/btn/btn3_name","");
		save("bots/$un/data/btn/btn4_name","");
		
		save("bots/$un/data/btn/btn1_post","");
		save("bots/$un/data/btn/btn2_post","");
		save("bots/$un/data/btn/btn3_post","");
		save("bots/$un/data/btn/btn4_post","");
	
		save("bots/$un/data/setting/sticker.txt","✅");
		save("bots/$un/data/setting/video.txt","✅");
		save("bots/$un/data/setting/voice.txt","✅");
		save("bots/$un/data/setting/file.txt","✅");
		save("bots/$un/data/setting/photo.txt","✅");
		save("bots/$un/data/setting/music.txt","✅");
		save("bots/$un/data/setting/forward.txt","✅");
		save("bots/$un/data/setting/joingp.txt","✅");
		

		$source = file_get_contents("bot/pv.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🚀 ربات شما با موفقیت نصب شد !",		
                'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
			SendMessage($logch,"`🎗ربات جدیدی در سرور ربات ثبت گردید . . .`

ℹ️اطلاعات ربات ثبت شده :

🔸*Bot Username :* [$un](http://t.me/$un)
🔹*Bot Admin :* [$name](http://t.me/$username)
🔸*Bot Model :* 💬 ربات پیام رسان");
		}
}
}
#=====VIP=====#
elseif ($step == 'xovip') {
$token = $textmessage ;

			$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
			//==================
			function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}

	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
		if($ok != 1) {
			//Token Not True
			SendMessage($chat_id,"توکن نامعتبر!");
		}
		else
		{
		SendMessage($chat_id,"در حال ساخت ربات ...");
		file_put_contents("bots/$un/vip.txt","vip");
		file_put_contents("bots/$un/ad_vip.txt","soros_robot");
        file_put_contents("bots/$un/step.txt","none");
		file_put_contents("bots/$un/users.txt","");
		file_put_contents("bots/$un/token.txt","$text");
        file_put_contents("bots/$un/start.txt","سلام 😊👋
به ربات دوز خوش اومدي ! ❤️‌ , اگه ميخواي تو گروهات يا پي وي هات با دوستات دوز بازي كنيد و حوصلتون سر رفته روي شروع بازي بزن و بازيو شروع كن😉 وقتي بازي تموم شد  نتايج اعلام ميشه");
		if (file_exists("bots/$un/index.php")) {
		$source = file_get_contents("bot/xovip.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"♻️🚀 ربات شما با موفقیت آپدیت شد !",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
		}
		else {
		save("data/$from_id/tedad.txt","1");
		save("data/$from_id/step.txt","none");
		save("data/$from_id/bots.txt","$un");
		
		mkdir("bots/$un");
		mkdir("bots/$un/data");
		mkdir("bots/$un/data/btn");
		mkdir("bots/$un/data/words");
		mkdir("bots/$un/data/profile");
		mkdir("bots/$un/data/setting");
		
		save("bots/$un/data/blocklist.txt","");
		save("bots/$un/data/last_word.txt","");
		save("bots/$un/data/pmsend_txt.txt","📮Message Sent!");
		save("bots/$un/data/start_txt.txt","Hello Wellcome To My Robot 😉👌
Send Me Your Message 🌹");
		save("bots/$un/data/forward_id.txt","");
		save("bots/$un/data/users.txt","$from_id\n");
		mkdir("bots/$un/data/$from_id");
		save("bots/$un/data/$from_id/type.txt","admin");
		save("bots/$un/data/$from_id/step.txt","none");
		
		save("bots/$un/data/btn/btn1_name","");
		save("bots/$un/data/btn/btn2_name","");
		save("bots/$un/data/btn/btn3_name","");
		save("bots/$un/data/btn/btn4_name","");
		
		save("bots/$un/data/btn/btn1_post","");
		save("bots/$un/data/btn/btn2_post","");
		save("bots/$un/data/btn/btn3_post","");
		save("bots/$un/data/btn/btn4_post","");
	
		save("bots/$un/data/setting/sticker.txt","✅");
		save("bots/$un/data/setting/video.txt","✅");
		save("bots/$un/data/setting/voice.txt","✅");
		save("bots/$un/data/setting/file.txt","✅");
		save("bots/$un/data/setting/photo.txt","✅");
		save("bots/$un/data/setting/music.txt","✅");
		save("bots/$un/data/setting/forward.txt","✅");
		save("bots/$un/data/setting/joingp.txt","✅");
		
		file_put_contents("bots/$un/vip.txt","vip");
		file_put_contents("bots/$un/ad_vip.txt","soros_robot");
        file_put_contents("bots/$un/step.txt","none");
		file_put_contents("bots/$un/users.txt","");
		file_put_contents("bots/$un/token.txt","$text");
        file_put_contents("bots/$un/start.txt","سلام 😊👋
به ربات دوز خوش اومدي ! ❤️‌ , اگه ميخواي تو گروهات يا پي وي هات با دوستات دوز بازي كنيد و حوصلتون سر رفته روي شروع بازي بزن و بازيو شروع كن😉 وقتي بازي تموم شد  نتايج اعلام ميشه");
		$source = file_get_contents("bot/xovip.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🚀 ربات شما با موفقیت نصب شد !",		
                'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
			SendMessage($logch,"`🎗ربات جدیدی در سرور ربات ثبت گردید . . .`

ℹ️اطلاعات ربات ثبت شده :

🔸*Bot Username :* [$un](http://t.me/$un)
🔹*Bot Admin :* [$name](http://t.me/$username)
🔸*Bot Model :* ❌ ربات Xo ویژه");
		}
}
}
elseif ($step == 'uinfovip') {
$token = $textmessage ;

			$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
			//==================
			function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}

	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
		if($ok != 1) {
			//Token Not True
			SendMessage($chat_id,"توکن نامعتبر!");
		}
		else
		{
		SendMessage($chat_id,"در حال ساخت ربات ...");
		if (file_exists("bots/$un/index.php")) {
		$source = file_get_contents("bot/uinfovip.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"♻️🚀 ربات شما با موفقیت آپدیت شد !",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
		}
		else {
		save("data/$from_id/tedad.txt","1");
		save("data/$from_id/step.txt","none");
		save("data/$from_id/bots.txt","$un");
		
		mkdir("bots/$un");
		mkdir("bots/$un/data");
		mkdir("bots/$un/data/btn");
		mkdir("bots/$un/data/words");
		mkdir("bots/$un/data/profile");
		mkdir("bots/$un/data/setting");
		
		save("bots/$un/data/blocklist.txt","");
		save("bots/$un/data/last_word.txt","");
		save("bots/$un/data/pmsend_txt.txt","📮Message Sent!");
		save("bots/$un/data/start_txt.txt","Hello Wellcome To My Robot 😉👌
Send Me Your Message 🌹");
		save("bots/$un/data/forward_id.txt","");
		save("bots/$un/data/users.txt","$from_id\n");
		mkdir("bots/$un/data/$from_id");
		save("bots/$un/data/$from_id/type.txt","admin");
		save("bots/$un/data/$from_id/step.txt","none");
		
		save("bots/$un/data/btn/btn1_name","");
		save("bots/$un/data/btn/btn2_name","");
		save("bots/$un/data/btn/btn3_name","");
		save("bots/$un/data/btn/btn4_name","");
		
		save("bots/$un/data/btn/btn1_post","");
		save("bots/$un/data/btn/btn2_post","");
		save("bots/$un/data/btn/btn3_post","");
		save("bots/$un/data/btn/btn4_post","");
	
		save("bots/$un/data/setting/sticker.txt","✅");
		save("bots/$un/data/setting/video.txt","✅");
		save("bots/$un/data/setting/voice.txt","✅");
		save("bots/$un/data/setting/file.txt","✅");
		save("bots/$un/data/setting/photo.txt","✅");
		save("bots/$un/data/setting/music.txt","✅");
		save("bots/$un/data/setting/forward.txt","✅");
		save("bots/$un/data/setting/joingp.txt","✅");
		

		$source = file_get_contents("bot/uinfovip.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🚀 ربات شما با موفقیت نصب شد !",		
                'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
			SendMessage($logch,"`🎗ربات جدیدی در سرور ربات ثبت گردید . . .`

ℹ️اطلاعات ربات ثبت شده :

🔸*Bot Username :* [$un](http://t.me/$un)
🔹*Bot Admin :* [$name](http://t.me/$username)
🔸*Bot Model :* 👤 ربات یوزر اینفو ویژه");
		}
}
}
elseif ($step == 'fmvip') {
$token = $textmessage ;

			$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
			//==================
			function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}

	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
		if($ok != 1) {
			//Token Not True
			SendMessage($chat_id,"توکن نامعتبر!");
		}
		else
		{
		SendMessage($chat_id,"در حال ساخت ربات ...");
		if (file_exists("bots/$un/index.php")) {
		$source = file_get_contents("bot/fmvip.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"♻️🚀 ربات شما با موفقیت آپدیت شد !",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
		}
		else {
		save("data/$from_id/tedad.txt","1");
		save("data/$from_id/step.txt","none");
		save("data/$from_id/bots.txt","$un");
		
		mkdir("bots/$un");
		mkdir("bots/$un/data");
		mkdir("bots/$un/data/btn");
		mkdir("bots/$un/data/words");
		mkdir("bots/$un/data/profile");
		mkdir("bots/$un/data/setting");
		
		save("bots/$un/data/blocklist.txt","");
		save("bots/$un/data/last_word.txt","");
		save("bots/$un/data/pmsend_txt.txt","📮Message Sent!");
		save("bots/$un/data/start_txt.txt","Hello Wellcome To My Robot 😉👌
Send Me Your Message 🌹");
		save("bots/$un/data/forward_id.txt","");
		save("bots/$un/data/users.txt","$from_id\n");
		mkdir("bots/$un/data/$from_id");
		save("bots/$un/data/$from_id/type.txt","admin");
		save("bots/$un/data/$from_id/step.txt","none");
		
		save("bots/$un/data/btn/btn1_name","");
		save("bots/$un/data/btn/btn2_name","");
		save("bots/$un/data/btn/btn3_name","");
		save("bots/$un/data/btn/btn4_name","");
		
		save("bots/$un/data/btn/btn1_post","");
		save("bots/$un/data/btn/btn2_post","");
		save("bots/$un/data/btn/btn3_post","");
		save("bots/$un/data/btn/btn4_post","");
	
		save("bots/$un/data/setting/sticker.txt","✅");
		save("bots/$un/data/setting/video.txt","✅");
		save("bots/$un/data/setting/voice.txt","✅");
		save("bots/$un/data/setting/file.txt","✅");
		save("bots/$un/data/setting/photo.txt","✅");
		save("bots/$un/data/setting/music.txt","✅");
		save("bots/$un/data/setting/forward.txt","✅");
		save("bots/$un/data/setting/joingp.txt","✅");
		

		$source = file_get_contents("bot/fmvip.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🚀 ربات شما با موفقیت نصب شد !",		
                'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
			SendMessage($logch,"`🎗ربات جدیدی در سرور ربات ثبت گردید . . .`

ℹ️اطلاعات ربات ثبت شده :

🔸*Bot Username :* [$un](http://t.me/$un)
🔹*Bot Admin :* [$name](http://t.me/$username)
🔸*Bot Model :* 📧 ربات فیک میل ویژه");
		}
}
}
elseif ($step == 'shvip') {
$token = $textmessage ;

			$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
			//==================
			function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}

	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
		if($ok != 1) {
			//Token Not True
			SendMessage($chat_id,"توکن نامعتبر!");
		}
		else
		{
		SendMessage($chat_id,"در حال ساخت ربات ...");
		if (file_exists("bots/$un/index.php")) {
		$source = file_get_contents("bot/shvip.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"♻️🚀 ربات شما با موفقیت آپدیت شد !",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
		}
		else {
		save("data/$from_id/tedad.txt","1");
		save("data/$from_id/step.txt","none");
		save("data/$from_id/bots.txt","$un");
		
		mkdir("bots/$un");
		mkdir("bots/$un/data");
		mkdir("bots/$un/data/btn");
		mkdir("bots/$un/data/words");
		mkdir("bots/$un/data/profile");
		mkdir("bots/$un/data/setting");
		
		save("bots/$un/data/blocklist.txt","");
		save("bots/$un/data/last_word.txt","");
		save("bots/$un/data/pmsend_txt.txt","📮Message Sent!");
		save("bots/$un/data/start_txt.txt","Hello Wellcome To My Robot 😉👌
Send Me Your Message 🌹");
		save("bots/$un/data/forward_id.txt","");
		save("bots/$un/data/users.txt","$from_id\n");
		mkdir("bots/$un/data/$from_id");
		save("bots/$un/data/$from_id/type.txt","admin");
		save("bots/$un/data/$from_id/step.txt","none");
		
		save("bots/$un/data/btn/btn1_name","");
		save("bots/$un/data/btn/btn2_name","");
		save("bots/$un/data/btn/btn3_name","");
		save("bots/$un/data/btn/btn4_name","");
		
		save("bots/$un/data/btn/btn1_post","");
		save("bots/$un/data/btn/btn2_post","");
		save("bots/$un/data/btn/btn3_post","");
		save("bots/$un/data/btn/btn4_post","");
	
		save("bots/$un/data/setting/sticker.txt","✅");
		save("bots/$un/data/setting/video.txt","✅");
		save("bots/$un/data/setting/voice.txt","✅");
		save("bots/$un/data/setting/file.txt","✅");
		save("bots/$un/data/setting/photo.txt","✅");
		save("bots/$un/data/setting/music.txt","✅");
		save("bots/$un/data/setting/forward.txt","✅");
		save("bots/$un/data/setting/joingp.txt","✅");
		

		$source = file_get_contents("bot/shvip.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🚀 ربات شما با موفقیت نصب شد !",		
                'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
			SendMessage($logch,"`🎗ربات جدیدی در سرور ربات ثبت گردید . . .`

ℹ️اطلاعات ربات ثبت شده :

🔸*Bot Username :* [$un](http://t.me/$un)
🔹*Bot Admin :* [$name](http://t.me/$username)
🔸*Bot Model :* 🔗 ربات کوتاه کننده لینک ویژه");
		}
}
}
elseif ($step == 'pvvip') {
$token = $textmessage ;

			$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
			//==================
			function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}

	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
		if($ok != 1) {
			//Token Not True
			SendMessage($chat_id,"توکن نامعتبر!");
		}
		else
		{
		SendMessage($chat_id,"در حال ساخت ربات ...");
		if (file_exists("bots/$un/index.php")) {
		$source = file_get_contents("bot/pvvip.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"♻️🚀 ربات شما با موفقیت آپدیت شد !",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
		}
		else {
		save("data/$from_id/tedad.txt","1");
		save("data/$from_id/step.txt","none");
		save("data/$from_id/bots.txt","$un");
		
		mkdir("bots/$un");
		mkdir("bots/$un/data");
		mkdir("bots/$un/data/btn");
		mkdir("bots/$un/data/words");
		mkdir("bots/$un/data/profile");
		mkdir("bots/$un/data/setting");
		
		save("bots/$un/data/blocklist.txt","");
		save("bots/$un/data/last_word.txt","");
		save("bots/$un/data/pmsend_txt.txt","📮Message Sent!");
		save("bots/$un/data/start_txt.txt","Hello Wellcome To My Robot 😉👌
Send Me Your Message 🌹");
		save("bots/$un/data/forward_id.txt","");
		save("bots/$un/data/users.txt","$from_id\n");
		mkdir("bots/$un/data/$from_id");
		save("bots/$un/data/$from_id/type.txt","admin");
		save("bots/$un/data/$from_id/step.txt","none");
		
		save("bots/$un/data/btn/btn1_name","");
		save("bots/$un/data/btn/btn2_name","");
		save("bots/$un/data/btn/btn3_name","");
		save("bots/$un/data/btn/btn4_name","");
		
		save("bots/$un/data/btn/btn1_post","");
		save("bots/$un/data/btn/btn2_post","");
		save("bots/$un/data/btn/btn3_post","");
		save("bots/$un/data/btn/btn4_post","");
	
		save("bots/$un/data/setting/sticker.txt","✅");
		save("bots/$un/data/setting/video.txt","✅");
		save("bots/$un/data/setting/voice.txt","✅");
		save("bots/$un/data/setting/file.txt","✅");
		save("bots/$un/data/setting/photo.txt","✅");
		save("bots/$un/data/setting/music.txt","✅");
		save("bots/$un/data/setting/forward.txt","✅");
		save("bots/$un/data/setting/joingp.txt","✅");
		

		$source = file_get_contents("bot/pvvip.php");
		$source = str_replace("**TOKEN**",$token,$source);
		$source = str_replace("**ADMIN**",$from_id,$source);
		save("bots/$un/index.php",$source);	
		file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=https://aminreza.000webhostapp.com/crphp/bots/$un/index.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🚀 ربات شما با موفقیت نصب شد !",		
                'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'inline_keyboard'=>[
                [
                   ['text'=>'ربات شما','url'=>"https://telegram.me/$un"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
			SendMessage($logch,"`🎗ربات جدیدی در سرور ربات ثبت گردید . . .`

ℹ️اطلاعات ربات ثبت شده :

🔸*Bot Username :* [$un](http://t.me/$un)
🔹*Bot Admin :* [$name](http://t.me/$username)
🔸*Bot Model :* 💬 ربات پیام رسان ویژه");
		}
}
}
elseif (strpos($textmessage, "/setvip2") !== false) {
$botun = str_replace("/setvip2 ","",$textmessage);
SendMessage($chat_id,"$textmessage");
$src = file_get_contents("bots/$botun/index.php");
$nsrc = str_replace("free","gold",$src);
save("data/$botun/index.php",$nsrc);
SendMessage($chat_id,"Updated!");
}
elseif ($textmessage == '📋 آمار ربات' && $from_id == $admin) {
$number = count(scandir("bots"))-1;
 $usercount = -1;
 $fp = fopen( "data/users.txt", 'r');
 while( !feof( $fp)) {
      fgets( $fp);
      $usercount ++;
 }
 fclose( $fp);
 SendMessage($chat_id,"📋 تعداد اعضای ربات : ".$usercount."
🤖 تعداد رباتهای فعال : $number

🌟 اعضای ویژه ربات :
$vip
⚫️ اعضای بلاک شده ربات :
$ban");
 }
 elseif ($textmessage == '🗣 پیام همگانی')
if ($from_id == $admin)
{
save("data/$from_id/step.txt","sendtoall");
var_dump(makereq('sendMessage',[
'chat_id'=>$update->message->chat->id,
'text'=>"🔸 لطفا پیام خود را ارسال کنید :",
'parse_mode'=>'MarkDown',

                               ]
        )
    );
}
else
{
SendMessage($chat_id,"😐📛شما ادمین نیستید.");
}
elseif ($step == 'sendtoall')
{
SendMessage($chat_id,"`📢 در حال ارسال . . .`");
save("data/$from_id/step.txt","none");
$fp = fopen( "data/users.txt", 'r');
while( !feof( $fp)) {
$ckar = fgets( $fp);
SendMessage($ckar,$textmessage);
}
SendMessage($chat_id,"✅ پیام شما به همه ی کاربران ربات ارسال گردید.");
}
elseif ($textmessage == '📢 فروارد همگانی')
if ($from_id == $admin)
{
save("data/$from_id/step.txt","fortoall");
var_dump(makereq('sendMessage',[
'chat_id'=>$update->message->chat->id,
'text'=>"🔹 لطفا پیام خود را فوروارد کنید :",
'parse_mode'=>'MarkDown',

                               ]
        )
    );
}
else
{
SendMessage($chat_id,"😐📛شما ادمین نیستید.");
}
elseif ($step == 'fortoall')
{
SendMessage($chat_id,"`📢 در حال فروارد پیام . . .`");
save("data/$from_id/step.txt","none");
$forp = fopen( "data/users.txt", 'r');
while( !feof( $forp)) {
$fakar = fgets( $forp);
Forward($fakar, $chat_id,$message_id);
  }
   makereq('sendMessage',[
   'chat_id'=>$chat_id,
   'text'=>"✅ پیام شما به همه ی کاربران ربات فروارد شد.",
   ]);
}
elseif (strpos($textmessage , "/toall") !== false ) {
if ($from_id == $admin) {
$text = str_replace("/toall","",$textmessage);
$fp = fopen( "data/users.txt", 'r');
while( !feof( $fp)) {
 $users = fgets( $fp);
SendMessage($users,"$text");
}
}
else {
SendMessage($chat_id,"شما ادمین نیستید.");
}
}
elseif (strpos($textmessage , "/feedback") !== false ) {
if ($from_id == $ban) {
$text = str_replace("/feedback","",$textmessage);
SendMessage($chat_id,"-");
SendMessage($admin,"-");
}
else {
$text = str_replace("/feedback","",$textmessage);
SendMessage($chat_id,"✅ نظر شما ارسال شد.");
SendMessage($admin,"`FeedBack :` \n\n*🔹Name :* [$name](http://t.me/$username)\n*🔹ID :* $from_id\n*🔹Text :* 👇\n$text");
SendMessage($logch,"`FeedBack :` \n\n*🔹Name :* [$name](http://t.me/$username)\n*🔹ID :* $from_id\n*🔹Text :* 👇\n$text");
}
}
elseif (strpos($textmessage , "/report") !== false ) {
if ($from_id == $ban) {
$text = str_replace("/report","",$textmessage);
SendMessage($chat_id,"-");
SendMessage($admin,"-");
}
else {
$text = str_replace("/report","",$textmessage);
SendMessage($chat_id,"❗️بعد از تایید ادمین ربات درخواستی بن میشود.");
SendMessage($admin,"`Report :` \n\n*🔸Name:* [$name](http://t.me/$username)\n*🔸ID :* $from_id\n*🔸Text :* 👇\n$text");
SendMessage($logch,"`Report :` \n\n*🔸Name:* [$name](http://t.me/$username)\n*🔸ID :* $from_id\n*🔸Text :* 👇\n$text");
}
}
elseif($textmessage == '🚀 ربات های من')
{
$botname = file_get_contents("data/$from_id/bots.txt");
if ($botname == "") {
SendMessage($chat_id,"شما هنوز هیچ رباتی نساخته اید !");
return;
}
 	var_dump(makereq('sendMessage',[
	'chat_id'=>$update->message->chat->id,
	'text'=>"لیست ربات های شما : ",
	'parse_mode'=>'MarkDown',
	'reply_markup'=>json_encode([
	'inline_keyboard'=>[
	[
	['text'=>"👉 @".$botname,'url'=>"https://telegram.me/".$botname]
	]
	]
	])
	]));
}
elseif($textmessage == '/start' )
{
if (!file_exists("data/$from_id/step.txt")) {
mkdir("data/$from_id");
save("data/$from_id/step.txt","none");
save("data/$from_id/tedad.txt","0");
save("data/$from_id/bots.txt","");
$myfile2 = fopen("data/users.txt", "a") or die("Unable to open file!"); 
fwrite($myfile2, "$from_id\n");
fclose($myfile2);
}

var_dump(makereq('sendMessage',[
         'chat_id'=>$update->message->chat->id,
         'text'=>"😎 سلام [$name](http://t.me/$username) !
📢 به سرویس هوشمند ساخت ربات PHP خوش اومدید.

🔸برای دریافت اطلاعات بیشتر بر روی دکمه ℹ️ راهنما کلیک کنید.
👤Creator : @SudoAmin",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
                   ['text'=>"🔄 ساخت ربات"],['text'=>"🚀 ربات های من"]
                ],
                [
				   ['text'=>"☢ حذف ربات"],['text'=>"ℹ️ راهنما"]
				],
                [
                   ['text'=>"✅ ارسال نظر"],['text'=>"⚠️ گزارش تخلف"]
                ],
           [
                ['text'=>"🗣 پشتیبانی"]
            ]
                
             ],
             'resize_keyboard'=>true
         ])
      ]));
}

elseif($textmessage == 'ℹ️ راهنما') {
SendMessage($chat_id, "🔶 این ربات با امکانات زیادی در اختیار کاربران تلگرام قرار گرفته است.

🚀 سرعت بسیار بالا
🗣 پشتیبانی آنلاین
🔰 اضافه شدن امکانات بیشتر به مرور زمان . . .

🔸برای دریافت آموزش گرفتن توکن از بات فادر بر روی دستور زیر کلیک کنید :
/howbot");
}
elseif($textmessage == '🗣 پشتیبانی' ) {
SendMessage($chat_id, "👤 پشتیبانی : @SudoAmin
🤖 ربات پشتیبانی : @SuCrPvBot");
}
elseif($textmessage == '/howbot') {
SendMessage($chat_id, "🔮آموزش گرفتن توکن از بات فادر و ساخت ربات :

1⃣دستور /newbot را در بات فادر ( @BotFather ) ارسال میکنید.
2⃣اسم ربات را وارد میکنید.
3⃣یوزرنیم بات را وارد میکنید.
مثال:
TestttBot
🌀نکته: در آخر یوزرنیم از حتما کلمه bot استفاده کنید.
4⃣حالا بات فادر متنی رو برای شما ارسال میکنید.
مثال:
Done! Congratulations on your new bot. You will find it at t.me/un. You can now add a description, about section and profile picture for your bot, see /help for a list of commands. By the way, when you've finished creating your cool bot, ping our Bot Support if you want a better username for it. Just make sure the bot is fully operational before you do this.

Use this token to access the HTTP API:
308266295:AAHEj9a-a-4OiWgYHlUK5LdLVehp843eppo

For a description of the Bot API, see this page: https://core.telegram.org/bots/api
6⃣حالا توکن شما حالتش میشه مثل مثال.
مثال:
308266295:AAHEj9a-a-4OiWgYHlUK5LdLVehp843eppo
🌀نکته: در این متن توکن ما این شد.
#⃣سپس توکن را برای من ارسال کنید و ربات خود را تحویل بگیرید.");
}
elseif($textmessage == '✅ ارسال نظر' ) {
SendMessage($chat_id, "🖊 نظرات شما به پیشرفت و ارائه خدمات بهتر کمک میکند.\n\n📝 برای ارسال نظر خوت از دستور زیر استفاده نمایید.\n\n/feedback (پیام خود را بنویسید)");
}
	elseif($textmessage == '⚠️ گزارش تخلف' ) {
SendMessage($chat_id, "🔰 اگر از رباتی شکایت دارید با دستور زیر شکایت خود را بیان کنید.

/report (UserName Bot) (متن شکایت)");
}
elseif ($textmessage == '☢ حذف ربات' ) {
if (file_exists("data/$from_id/step.txt")) {

}
$botname = file_get_contents("data/$from_id/bots.txt");
if ($botname == "") {
SendMessage($chat_id,"شما هنوز هیچ رباتی نساخته اید !");

}
else {
//save("data/$from_id/step.txt","delete");


 	var_dump(makereq('sendMessage',[
	'chat_id'=>$update->message->chat->id,
	'text'=>"یکی از ربات های خود را انتخاب کنید :",
	'parse_mode'=>'MarkDown',
	'reply_markup'=>json_encode([
	'inline_keyboard'=>[
	[
	['text'=>"👉 @".$botname,'callback_data'=>"del ".$botname]
	]
	]
	])
	]));

/*
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"یکی از ربات های خود را جهت پاک کردن انتخاب کنید : ",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
            	[
            	['text'=>$botname]
            	],
                [
                   ['text'=>"🔙 برگشت"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		])); */
}
}
elseif ($textmessage == '❌ ساخت ربات Xo' ) {

$tedad = file_get_contents("data/$from_id/0.txt");
if ($tedad >= 1) {
SendMessage($chat_id,"تعداد ربات های ساخته شده شما زیاد است !
اول باید یک ربات را پاک کنید ! $tedad");
return;
}
save("data/$from_id/step.txt","xo");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"توکن را وارد کنید :",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت به بخش عادی"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
}
elseif ($textmessage == '👤 ساخت ربات یوزر اینفو' ) {

$tedad = file_get_contents("data/$from_id/0.txt");
if ($tedad >= 1) {
SendMessage($chat_id,"تعداد ربات های ساخته شده شما زیاد است !
اول باید یک ربات را پاک کنید ! $tedad");
return;
}
save("data/$from_id/step.txt","uinfo");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"توکن را وارد کنید :",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت به بخش عادی"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
}
elseif ($textmessage == '📧 ساخت ربات فیک میل' ) {

$tedad = file_get_contents("data/$from_id/0.txt");
if ($tedad >= 1) {
SendMessage($chat_id,"تعداد ربات های ساخته شده شما زیاد است !
اول باید یک ربات را پاک کنید ! $tedad");
return;
}
save("data/$from_id/step.txt","fm");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"توکن را وارد کنید :",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت به بخش عادی"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
}
elseif ($textmessage == '🔗 ساخت ربات کوتاه کننده لینک' ) {

$tedad = file_get_contents("data/$from_id/0.txt");
if ($tedad >= 1) {
SendMessage($chat_id,"تعداد ربات های ساخته شده شما زیاد است !
اول باید یک ربات را پاک کنید ! $tedad");
return;
}
save("data/$from_id/step.txt","sh");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"توکن را وارد کنید :",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت به بخش عادی"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
}
elseif ($textmessage == '💬 ساخت ربات پیام رسان' ) {

$tedad = file_get_contents("data/$from_id/0.txt");
if ($tedad >= 1) {
SendMessage($chat_id,"تعداد ربات های ساخته شده شما زیاد است !
اول باید یک ربات را پاک کنید ! $tedad");
return;
}
save("data/$from_id/step.txt","pv");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"توکن را وارد کنید :",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت به بخش عادی"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
}
//=====vip=====//
elseif ($textmessage == '❌ ساخت ربات Xo ویژه' ) {
if (strpos($vip , "$from_id") !== false  ) {
save("data/$from_id/step.txt","xovip");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"توکن را وارد کنید :",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت به بخش ویژه"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
return;
}
SendMessage($chat_id,"⚜️ متاسفانه حساب شما عادی است");
}
elseif ($textmessage == '👤 ساخت ربات یوزر اینفو ویژه' ) {
if (strpos($vip , "$from_id") !== false  ) {
save("data/$from_id/step.txt","uinfovip");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"توکن را وارد کنید :",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت به بخش ویژه"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
return;
}
SendMessage($chat_id,"⚜️ متاسفانه حساب شما عادی است");
}
elseif ($textmessage == '📧 ساخت ربات فیک میل ویژه' ) {
if (strpos($vip , "$from_id") !== false  ) {
save("data/$from_id/step.txt","fmvip");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"توکن را وارد کنید :",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت به بخش ویژه"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
return;
}
SendMessage($chat_id,"⚜️ متاسفانه حساب شما عادی است");
}

elseif ($textmessage == '🔗 ساخت ربات کوتاه کننده لینک ویژه' ) {
if (strpos($vip , "$from_id") !== false  ) {
save("data/$from_id/step.txt","shvip");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"توکن را وارد کنید :",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت به بخش ویژه"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
return;
}
SendMessage($chat_id,"⚜️ متاسفانه حساب شما عادی است");
}
elseif ($textmessage == '💬 ساخت ربات پیام رسان ویژه' ) {
if (strpos($vip , "$from_id") !== false  ) {
save("data/$from_id/step.txt","pvvip");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"توکن را وارد کنید :",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت به بخش ویژه"]
                ]
                
            	],
            	'resize_keyboard'=>true
       		])
    		]));
return;
}
SendMessage($chat_id,"⚜️ متاسفانه حساب شما عادی است");
}
	elseif (strpos($textmessage , "/setvip" ) !== false ) {
if ($from_id == $admin) {
$text = str_replace("/setvip","",$textmessage);
$myfile2 = fopen("data/vip.txt", 'a') or die("Unable to open file!");	
fwrite($myfile2, "$text\n");
fclose($myfile2);
SendMessage($admin,"🔸عملیات ارتقا حساب با موفقیت انجام شد و کاربر$text به لیست اعضای ویژه اضافه شد.");
SendMessage($logch,"👤🌟 کاربر $text به لیست اعضای ویژه اضافه گردید.");
}
else {
SendMessage($chat_id,"⛔️ شما ادمین نیستید.");
}
}

elseif (strpos($textmessage , "/delvip" ) !== false ) {
if ($from_id == $admin) {
$text = str_replace("/delvip","",$textmessage);
			$newlist = str_replace($text,"",$vip);
			save("data/vip.txt",$newlist);
SendMessage($admin,"🔹کاربر$text با موفقیت از لیست اعضای ویژه حذف گردید.");
SendMessage($logch,"👤 کاربر $text از لیست اعضای ویژه حذف گردید.");
}
else {
SendMessage($chat_id,"⛔️ شما ادمین نیستید.");
}
}
	elseif (strpos($textmessage , "/ban" ) !== false ) {
if ($from_id == $admin) {
$text = str_replace("/ban","",$textmessage);
$myfile2 = fopen("data/banlist.txt", 'a') or die("Unable to open file!");	
fwrite($myfile2, "$text\n");
fclose($myfile2);
SendMessage($admin,"📢 کاربر$text از ربات بن شد.

برای آن بن کردن کاربر از دستور زیر استفاده کنید :
/unban$text");
SendMessage($logch,"😐📢 کاربر$text از سرور ربات سازی @CrPhpBot توسط ادمین مسدود شد.");
}
else {
SendMessage($chat_id,"⛔️ شما ادمین نیستید.");
}
}

elseif (strpos($textmessage , "/unban" ) !== false ) {
if ($from_id == $admin) {
$text = str_replace("/unban","",$textmessage);
			$newlist = str_replace($text,"",$ban);
			save("data/banlist.txt",$newlist);
SendMessage($admin,"📢 کاربر$text از ربات آن بن شد.");
SendMessage($logch,"😶📢 کاربر$text از لیست مسدود شده های سرور ربات سازی @CrPhpBot حذف شد.");
}
else {
SendMessage($chat_id,"⛔️ شما ادمین نیستید.");
}
}

elseif ($textmessage == '/panel')
 if ($from_id == $admin) {
var_dump(makereq('sendMessage',[
          'chat_id'=>$update->message->chat->id,
          'text'=>"به پنل مدیریت ربات خوش آمدید !",
  'parse_mode'=>'MarkDown',
         'reply_markup'=>json_encode([
             'keyboard'=>[
                [
                   ['text'=>"📋 آمار ربات"],['text'=>"🗣 پیام همگانی"]
				],
                [
				   ['text'=>"📢 فروارد همگانی"]
				],
                [
				   ['text'=>"🔙 خروج از پنل مدیریت"]
            ]
             ],
             'resize_keyboard'=>true
         ])
      ]));
}
else
{
SendMessage($chat_id,"😐📛شما ادمین نیستید.");
}
/*
--------
Channel=>@soros_robot
Channel=>@lite_team
--------
*/
?>
